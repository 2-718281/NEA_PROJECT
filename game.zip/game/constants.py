WIDTH: int = 800
HEIGHT = 600
FPS = 60
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
WHITE = (255,255,255)
TITLE = "this is a title"


FONT_NAME = "arial"
P_ACC = 0.5
P_FRI = -0.12
P_GRA = 0.5

CAM_VEL = 0.5

PLATFORM_LIST = [(0, HEIGHT - 60, 10000, 60),
                 (WIDTH / 2 - 50, HEIGHT * 3 / 4, 100, 20),
                 (1000, 300, 200, 10),
                 (1500, 200, 300, 20)]


