WIDTH = 1200
HEIGHT = 800
FPS = 30
BLACK = (0, 0, 0)
BLUE = (0,0,255)
TITLE = "test"

P_ACC = 0.5
P_FRI = -0.12


