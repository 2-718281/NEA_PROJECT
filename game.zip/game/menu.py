import pygame as pg


class MainMenu:
    def __init__(self):
        pass