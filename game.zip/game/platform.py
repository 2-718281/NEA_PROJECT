import pygame as pg
from constants import *


class Platform(pg.sprite.Sprite):
    def __init__(self, x, y, w, h, index):  # 平台类，坐标，长宽
        pg.sprite.Sprite.__init__(self)
        self.image = pg.Surface((w, h))  # 长宽
        self.image.fill(BLUE)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.index = index
