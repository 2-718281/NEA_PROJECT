import pygame as pg
from constants import *

pg.init()  # 初始化pygame
Screen = pg.display.set_mode((WIDTH, HEIGHT))  # 初始化显示
Screen_Rect = Screen.get_rect()